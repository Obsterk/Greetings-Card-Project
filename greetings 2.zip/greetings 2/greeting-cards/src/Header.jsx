const Header = () => {
    return (
      <header style={{ 
        textAlign: "center", 
        padding: "20px",
        backgroundColor: "#ffd700",
        color: "white", 
        fontSize: "2em",
        fontWeight: "bold",
      }}>
        <h1>Welcome to Greeting Cards</h1>
      </header>
    );
  };
  
  export default Header;